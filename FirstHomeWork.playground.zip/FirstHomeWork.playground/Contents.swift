import UIKit

var generatedArr: [Int] = []
let generatedCount = 200

while generatedArr.count < generatedCount {
    let randomInt = Int.random(in: 0...1000)
    generatedArr.append(randomInt)
}

let index = searchFirstEqual(arr: generatedArr)

func searchFirstEqual(arr: [Int]) -> Int {
    for firstIndex in 0..<arr.count - 1 {
        for secondIndex in (firstIndex + 1)..<arr.count {
            if arr[firstIndex] == arr[secondIndex] {
                return firstIndex
            }
        }
    }
    return -1
}

print("Сгенерированный массив \(generatedArr)")
print("Найденный индекс \(index)")
